---
name: king-audio-timed-remotion
description: Create complete Digital Life King Remotion lecture videos from final voice audio plus SRT or transcript. Use for Chinese talking-head courses that need word or phrase-synced keyword reveals, audio-driven visual changes, progress navigation, left-bottom facecam-safe layouts, bottom subtitle-safe space, and render-ready MP4 output.
---

# King Audio-Timed Remotion

## Required Input

Use the final recorded audio plus SRT whenever available. Treat the supplied script/SRT as the canonical wording; treat audio as the timing authority. Ask only for files that cannot be found in the user's provided folder.

## Timing Workflow

1. Extract or copy the audio used in the final composition.
2. Generate Chinese character timestamps with `scripts/transcribe_funasr.py` when local FunASR models are available. Set `FUNASR_MODEL_ROOT` to the folder containing the three `iic` model directories; the script otherwise checks the standard ModelScope user cache.
3. Check ASR sentence starts against the SRT. Correct model-recognized wording with the SRT rather than trusting ASR text for model names, numbers, or English terms.
4. Build a typed beat table. Every visible keyword, number, row, arrow, or state change must cite a phrase start time from that table.
5. Never reveal an element before the first spoken sound of its phrase. Begin opacity/short integer-pixel movement at the phrase onset and settle in 4-8 frames.

Use sentence timing only for whole-sentence visuals. For a later keyword inside a sentence, use its character timing or split the SRT cue before building the event.

## Local ASR Text Correction

Treat local ASR output as timing data first and text source second. Never put raw ASR wording directly into subtitles, on-screen keywords, or a JianYing draft without correction.

1. Preserve the raw ASR JSON unchanged. Create a separate corrected transcript/SRT and a correction log containing `raw`, `corrected`, timestamp range, and correction reason.
2. When an accurate transcript/SRT is supplied, use it as the wording authority and align it to the ASR timestamps. Keep ASR timing unless the supplied transcript clearly indicates a sentence-boundary mismatch.
3. When no canonical transcript exists, correct obvious homophones, punctuation, Chinese character errors, model/product names, English terms, proper nouns, and numbers using the audio context plus the user's project glossary. Do not invent material that cannot be supported by the audio.
4. Preserve the original start/end time for one-for-one corrections. For a split or merged cue, distribute the source duration across the corrected words/phrases and keep the result within the source sentence boundary.
5. Do not block delivery for uncertain corrections. Apply the best audio-supported correction, keep uncertain spans in the private correction log, and make every delivered subtitle editable in the JianYing draft so the user can correct it there.
6. Use the corrected transcript for visible animation labels, SRT import, and JianYing subtitle tracks; retain the raw transcript and correction log only as audit artifacts.

## Visual System

- Render native `1920x1080` at 30fps.
- Reserve the lower-left 30% x 40% for the presenter's face and the lower-center 150-180px for editor-added subtitles.
- Use warm paper grid background, a single `数字生命 King` mark, Noto Sans SC/Source Han Sans CN/Microsoft YaHei UI, and a crisp down-right hard shadow. Do not blur text, scale large text on entry, or use heavy outlines.
- Keep hierarchy to: one conclusion, one support line, then labels/numbers. Do not repeat the full narration on screen.
- Use a visual mode that matches the spoken idea: hook, mechanism, comparison, number, checklist, or conclusion. Change visual state every 6-10 seconds and make a larger scene reset every 20-35 seconds.
- Define non-overlapping layout zones for every scene before placing elements: title, support, card/diagram, navigation, presenter-safe area, and subtitle-safe area. Use a stack or grid inside each zone; do not place later labels by guesswork over a title or card.

## Large CJK Text

- Use an installed real bold face for titles, preferably `Noto Sans SC Bold`, with `fontWeight: 700`. Do not request `900` or `950` from a family that only ships a Bold weight; browser-synthesized weight softens edges.
- Use exactly one edge treatment: either a 1px integer stroke or an integer-pixel hard back layer. Do not combine fractional `WebkitTextStroke`, semi-transparent `text-shadow`, and synthetic bold.
- For the reference-style shadow, render a second copy behind the title at an integer offset such as `left: 2px; top: 3px`, with no blur; render the front title without a blur shadow. Keep the foreground edge clean.
- Compare a native-size still with a frame extracted from the final MP4. Fine colored text can degrade through low-bitrate H.264 4:2:0 encoding, so use a high-quality H.264 CRF/bitrate for delivery and verify the encoded frame.

## Navigation

Use one of two opening modes:

- Default hook mode: hide the full labelled rail and right-side guide during the first 10-15 seconds, so the hook owns attention.
- Early-orientation mode: show only a lightweight top rail from frame 0: short unlabelled segments plus `01 / total`. Do not show the right-side guide until the promise/roadmap begins.

After the promise/roadmap begins, show:

1. A compact top progress rail for the full video.
2. A right-side current-section guide with 3-4 steps. Mark completed steps dark, the active step yellow, and future steps low-contrast.

Keep both navigation layers visually quiet so the active teaching visual remains primary.

## Remotion Build

- Add `<Audio src={staticFile(...)} />` to the composition. Do not create a silent animation intended to be manually aligned later.
- Store beats and section steps in a dedicated TypeScript timeline file; do not hard-code arbitrary frame offsets inside visual components.
- Use typed scene data and phrase-based starts, e.g. `{at: beats.outputPrice, label: '输出通常更贵'}`.
- Expose genuinely useful layout/timing knobs as Remotion props when they need manual tuning.
- Remove all preview/debug UI from the final: current-speech cards, timestamps, and safe-area labels.

## JianYing Draft Handoff

When the user asks for a JianYing/CapCut draft after the Remotion animation is approved, use the local `jianying-editor` workflow to create a native, editable local draft rather than only delivering a flattened MP4.

1. Put the Remotion render on the base video track and retain its final audio as the single master audio source.
2. Import the user's talking-head source onto a separate PIP video track. Detect and track the primary/largest face, smooth its path, crop around it, apply a circular mask, and place it in the lower-left presenter-safe region. The default is a `280px` circular portrait with the face centered; expose size and x/y position as editable draft controls.
3. Prevent duplicate audio: mute or use an audio-free PIP copy of the talking-head source when the Remotion render already contains the narration.
4. Build an SRT from the canonical transcript plus audio-derived timestamps. Import that SRT as an editable JianYing subtitle track, not burned-in text. Default the subtitle track to the lower-center subtitle-safe zone and keep it clear of the PIP portrait.
5. If the input contains multiple faces, a face leaves the frame, or tracking confidence drops, choose the largest face only and record the affected time ranges for the user's review instead of silently applying an unreliable crop.
6. Save the draft directly under the local JianYing drafts root. Do not overwrite an existing user draft; use a dated, descriptive draft name.

Draft acceptance checklist:

- The saved draft opens in JianYing and has a base animation track, a PIP portrait track, and an editable subtitle track.
- Only one narration audio track is audible.
- Inspect the first, a middle, and a final frame to verify the face stays centered inside the circular mask and does not overlap subtitles or teaching content.
- Open the draft folder after creation. Keep any low-confidence face-tracking or transcript-correction notes in the project artifacts, without requiring a review step before delivery.

## Validation

1. Run `npx tsc --noEmit`.
2. Render stills at hook, dense list, comparison, and conclusion frames. For every progressive scene, render each new element's settled arrival frame and its **fully accumulated state**: at least 0.5 seconds after its last child element appears. Inspect text clarity, overlap, facecam space, and subtitle space.
3. Treat unplanned overlap as a release blocker. Check title/tag/card/diagram/navigation bounding regions at every arrival frame; elements may overlap only when one is an intentional child of the same card. Do not place independent absolute text over a flex/card composition whose occupied bounds can grow. Put the text inside that card, or use explicit grid columns with non-overlapping regions.
4. For every new title treatment, navigation mode, or encoding setting, make a separate 5-second MP4 from the actual opening audio. Include the intended first-frame progress treatment, then inspect a frame near the end of that sample before applying the style to the full video.
5. Review stills and 5-second local samples use no AI-model tokens and do not lengthen the delivered video; they only add local render time. Keep review frames proportional to scene count.
6. Render the MP4 in a single Remotion job. Verify it contains `1920x1080` video and an audio stream, then extract frames from the final MP4 at dense moments and compare them to the native stills.
7. Open the output project folder in Explorer after delivery.
