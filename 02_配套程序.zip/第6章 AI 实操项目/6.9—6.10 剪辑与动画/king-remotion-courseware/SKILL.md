---
name: king-remotion-courseware
description: Create Remotion courseware animations in the Digital Life King teaching style. Use when the user wants script/audio-driven Remotion lecture visuals, paper-grid course slides, left-bottom facecam-safe layouts, bottom subtitle-safe space, editable Remotion Studio props, or reusable animated lesson templates.
---

# King Remotion Courseware

## Core Workflow

1. Start from `assets/remotion-courseware-template` unless the user has an existing Remotion project.
2. Keep the composition native `1920x1080`. Do not render a 720p layout and enlarge it with CSS `scale()`: that softens text.
3. Reserve two safe areas:
   - left-bottom facecam zone: roughly the lower-left 30% width and 40% height.
   - bottom subtitle zone: keep the lower center clean unless the user explicitly wants burned-in subtitles.
4. Put main teaching content in the upper center and center-right, not only the far right.
5. Expose movable elements through `scenePropsSchema` and `defaultProps` so Remotion Studio can fine-tune positions and timing.
6. Render at least two stills before final output: a dense content frame and a conclusion/title frame.

## AI 课项目归档

课程动画属于已有课程项目时，先读取该项目的 README 或课程导航。正式课程输出到课程对应小节的 `课堂素材/视频/`；公开课或分享课输出到该专题的 `课件/`。不要在磁盘根目录新建临时成品目录。

## Visual Style

Use a lecture-paper look:

- background: warm paper color with low-contrast grid lines.
- brand mark: `数字生命 King` in the upper left.
- typography: prefer bundled, commercially safe/open-source Chinese fonts such as `Noto Sans SC` or `Source Han Sans CN`.
- when bundling fonts, preserve the original font files and include their license/notice. For Noto Sans SC, keep the SIL Open Font License 1.1 with the project.
- avoid downloading unknown commercial fonts or using fonts without a verifiable license.
- title color: clean warm yellow, not dirty brown.
- use clear 80–88 px titles at native 1920×1080, with an exact available bold weight.
- do not add title or subtitle shadows by default. Use a single text layer; add a thin solid stroke only when contrast needs it.
- avoid thick black outlines, duplicated text layers, blur filters, negative letter spacing, and viewport-scaled font sizes.

Recommended title CSS pattern:

```tsx
<div
  style={{
    position: 'relative',
    fontFamily: 'Noto Sans SC, Source Han Sans CN, Microsoft YaHei UI, sans-serif',
    fontSize: 88,
    fontWeight: 700,
    lineHeight: 1.08,
    letterSpacing: 0,
    color: '#a77d08',
    WebkitTextStroke: '0.6px rgba(70,52,20,0.62)',
    WebkitFontSmoothing: 'antialiased',
    textRendering: 'geometricPrecision',
  }}
>
  {text}
</div>
```

## Animation Rules

Treat animation as a response to speech beats:

- use real audio timestamps when available.
- make progress bars, counters, tables, list items, callouts, arrows, and highlights animate instead of appearing fully formed.
- avoid scaling large text during entrance; use opacity and integer-pixel translate only.
- animate table/list rows one by one.
- keep small idle movement subtle; the lecture must remain readable.

## Audio-Timed Build

When the user provides audio and script:

1. Transcribe or align the script to timestamps.
2. Convert beats to frame ranges at 30 fps.
3. Map each sentence to one visual action.
4. Keep subtitle-safe space empty for the user's editor.
5. Render stills at important beats and then render the final MP4.

## Template Usage

To create a new project from the bundled template, run:

```powershell
python "$HOME\.codex\skills\king-remotion-courseware\scripts\create_courseware_project.py" ".\my-new-remotion-course"
```

Then:

```powershell
cd ".\my-new-remotion-course"
npm install
npx tsc --noEmit
npm run render
```

## Validation Checklist

Before final delivery:

- title text is crisp at original frame size.
- title and subtitle text use no shadow or duplicated offset layer unless the user explicitly requests one.
- bundled fonts include a verifiable license/notice and do not rely on unlicensed commercial fonts.
- no whole-canvas CSS scale is used for final resolution.
- left-bottom facecam zone is clear.
- bottom-center subtitle zone is clear.
- no text overlaps after all elements are visible.
- animations include at least one content-specific motion, such as a counting number, filling bar, table row highlight, or underline reveal.
