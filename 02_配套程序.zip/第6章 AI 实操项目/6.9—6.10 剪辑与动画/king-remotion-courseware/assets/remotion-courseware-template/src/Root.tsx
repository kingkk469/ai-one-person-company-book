﻿import React from 'react';
import {Composition} from 'remotion';
import {MasterSequence} from './MasterSequence';
import {scenePropsSchema} from './sceneProps';
import {compositionDuration} from './storyboard';

export const Root: React.FC = () => {
  return (
    <Composition
      id="VoxOriginalMethod"
      component={MasterSequence}
      durationInFrames={compositionDuration}
      fps={30}
      width={1920}
      height={1080}
      schema={scenePropsSchema}
      defaultProps={{
        scene01: {
          eyebrow: {x: 0, y: 0, scale: 1, startFrame: 6},
          headline: {x: 0, y: 0, scale: 1, startFrame: 16},
          bubble: {x: 0, y: 0, scale: 1, startFrame: 54},
          meter: {x: 0, y: 0, scale: 1, startFrame: 76},
        },
        scene02: {
          headline: {x: 0, y: 0, scale: 1, startFrame: 8},
          tokenNumber: {x: 0, y: 0, scale: 1, startFrame: 28},
          formula: {x: 0, y: 0, scale: 1, startFrame: 64},
          note: {x: 0, y: 0, scale: 1, startFrame: 92},
        },
        scene03: {
          title: {x: 0, y: 0, scale: 1, startFrame: 8},
          table: {x: 0, y: 0, scale: 1, startFrame: 30},
          callout: {x: 0, y: 0, scale: 1, startFrame: 92},
        },
        scene04: {
          conclusion: {x: 0, y: 0, scale: 1, startFrame: 8},
          checklist: {x: 0, y: 0, scale: 1, startFrame: 48},
          finalLine: {x: 0, y: 0, scale: 1, startFrame: 112},
        },
      }}
    />
  );
};
