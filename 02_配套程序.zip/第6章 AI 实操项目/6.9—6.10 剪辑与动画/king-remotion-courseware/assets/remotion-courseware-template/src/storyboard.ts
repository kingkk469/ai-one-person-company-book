﻿export const storyboard = [
  {id: 'scene01', from: 0, duration: 150},
  {id: 'scene02', from: 150, duration: 140},
  {id: 'scene03', from: 290, duration: 170},
  {id: 'scene04', from: 460, duration: 150},
] as const;

export const compositionDuration = storyboard.reduce(
  (total, scene) => total + scene.duration,
  0,
);
