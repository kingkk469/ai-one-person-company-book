---
name: local-talking-head-editor
description: 本地口播视频的转写、字幕校正、逐句人工审校、价值优先审稿、语音剪辑、EDL、字幕重映射与本地交付工作流。用于“本地剪口播”“校正转写字幕”“逐句核听”“不上传 ChatCut”“直接输出 MP4/SRT”“用 ChatCut 做决策但在本地渲染”“代理文件进 ChatCut、高清原片留在本地”等需求，支持 local-only、hybrid-proxy 和 chatcut-full 三种模式。
---

# 本地口播剪辑

把内容判断与最终渲染分开：优先保留原片价值，默认先审稿，再用本机原文件输出成片。

## 不可违反的规则

- 不覆盖或修改原文件；输出使用安全的新文件名。
- 未经用户明确同意，不把真实素材上传到 ChatCut 或其他外部服务。
- 默认价值优先。只删除明确语气词、失败重说、完全重复和无意义长停顿。
- 不确定一句话是否有独立观点、例子、方法、情绪或承接价值时，保留。
- 默认在语义删除前展示“保留/删除/理由”审查稿；只有用户明确要求端到端完成时才跳过。
- 原始 ASR 只作识别底稿，不直接作为成片字幕。保留原始文件，校正版、人工审校版分别另存。
- 字幕纠错与语义删减分开：纠错不得创造原音中不存在的表达；听不清时标记待核听，不强行改通顺。
- 先定 A-roll 内容，再做字幕、B-roll、MG 动画和背景音乐。
- 用完整语义单元剪辑；不要把不同重说里的残句拼成一句人造表达。
- 输出前验证时长、分辨率、帧率、音轨、首尾和关键切点。

## 选择模式

1. `local-only`：素材和渲染全在本地。用于隐私优先、快速直接交付。
2. `hybrid-proxy`：默认推荐。上传保持时间轴一致的低码率代理文件给 ChatCut，用本地高清原片按相同 EDL 渲染。
3. `chatcut-full`：需要 ChatCut 专属 MG、复杂特效、在线协作或完全一致的在线预览时使用。

用户未指定时，根据需求推荐模式并说明传输边界。涉及真实素材上传时必须在行动前确认。

## 工作流

### 1. 本地预检

运行 `scripts/preflight.py` 检查媒体信息和工具依赖。确认源文件、音轨、帧率、分辨率和时长。

### 2. 转写

需要本地转写时运行 `scripts/transcribe.py`，生成词级时间戳 JSON、TXT 和 SRT。中文优先测试 Faster Whisper；如用户已有更好的 FunASR 配置，可替换转写引擎，但保持统一输出结构。

### 3. 字幕初校

在原始转写基础上校正常见错字、标点、断句和可确认的专有名词，另存校正版 JSON/TXT/SRT。不要覆盖原始转写。无法从上下文和原音可靠确认的内容标记待核听。

### 4. 审稿

完整阅读文字稿，按 `references/editorial-rules.md` 生成审查稿。明确列出：

- 建议删除的原句或片段
- 删除原因
- 必须保留的价值句
- 钩子或重排方案
- 预计成片时长范围

等待用户确认后再进行语义删除，除非用户明确说“直接完成”。

### 5. 逐句人工审校

用户需要核听或原始识别错误较多时，运行：

```powershell
python scripts/build_subtitle_reviewer.py --transcript <校正版.transcript.json> --video <原视频> --output <审校台.html>
```

页面应自动加载原视频，允许点击时间码核听、修改文字、标记删除、自动保存、恢复上一版，并导出人工审校 JSON/TXT/SRT。人工导出的 JSON 是后续内容选择和字幕制作的唯一依据。

### 6. 生成 EDL 与剪后字幕

优先从人工审校 JSON 生成：

```powershell
python scripts/reviewed_json_to_edl.py --review <人工审校.json> --source <原视频> --output-edl <edl.json> --output-srt <剪后字幕.srt>
```

脚本把相邻对白合并为完整语义片段，保留约 0.3-0.5 秒自然呼吸，删除用户排除的句子和较长空白，并把原片字幕时间码重映射到剪后时间轴。

也可以手工创建 EDL：

把确认后的保留区间保存成 JSON：

```json
{
  "version": 1,
  "source": "C:/path/source.mp4",
  "fps": 30,
  "width": 1920,
  "height": 1080,
  "segments": [
    {"start": 12.4, "end": 18.9, "label": "hook"}
  ]
}
```

所有时间均为原片秒数。保持顺序即为最终播放顺序。

### 7. 渲染

运行：

```powershell
python scripts/render_edl.py --edl <edl.json> --output <output.mp4>
```

默认 H.264、AAC、原分辨率、EDL 指定帧率，不覆盖已有文件。

### 8. 验证与交付

运行：

```powershell
python scripts/verify_output.py --video <output.mp4> --edl <edl.json>
```

同时抽查首帧、尾帧和每个主要切点。交付 MP4；用户需要时同时交付 SRT、EDL 和审查稿。

另行确认：人工审校句数与剪后字幕句数一致；字幕时间无倒置、负数或越界；EDL 区间有序且不重叠；成片实际时长与 EDL 预计时长相符。

## 混合代理模式

使用 `hybrid-proxy` 时必须阅读 `references/hybrid-proxy.md`。确保代理和原片帧率、时长、音频起点一致；从 ChatCut 读取源区间后，本地 EDL 必须以高清原片时间轴为准。

## 学习与更新

遇到未知场景时阅读 `references/learning-protocol.md`。先查现有规则，再查公开文档；仍不确定时使用非敏感样例咨询 ChatCut。只有经过用户评价和回归验证的通用规则才写回 Skill。
