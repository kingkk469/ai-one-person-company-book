﻿import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {SceneProps} from './sceneProps';
import {storyboard} from './storyboard';
import {SharedBackground} from './scenes/SharedBackground';
import {Scene01, Scene02, Scene03, Scene04} from './scenes/TokenSlides';

export const MasterSequence: React.FC<SceneProps> = (props) => {
  return (
    <AbsoluteFill style={{background: '#f3efe6', overflow: 'hidden'}}>
      <SharedBackground />
      {storyboard.map((scene, index) => (
        <Sequence key={scene.id} from={scene.from} durationInFrames={scene.duration} layout="none">
          <SceneRenderer index={index} props={props} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};

const SceneRenderer: React.FC<{
  index: number;
  props: SceneProps;
}> = ({index, props}) => {
  const frame = useCurrentFrame();

  if (index === 0) {
    return <Scene01 frame={frame} props={props.scene01} />;
  }

  if (index === 1) {
    return <Scene02 frame={frame} props={props.scene02} />;
  }

  if (index === 2) {
    return <Scene03 frame={frame} props={props.scene03} />;
  }

  return <Scene04 frame={frame} props={props.scene04} />;
};
