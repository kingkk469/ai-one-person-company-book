﻿import React from 'react';
import {AbsoluteFill} from 'remotion';

export const SharedBackground: React.FC = () => {
  return (
    <AbsoluteFill
      style={{
        background: '#f3efe6',
        overflow: 'hidden',
        fontFamily: 'Noto Sans SC, Source Han Sans CN, Microsoft YaHei UI, Microsoft YaHei, Arial, sans-serif',
      }}
    >
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage:
            'linear-gradient(rgba(66,58,46,0.085) 1px, transparent 1px), linear-gradient(90deg, rgba(66,58,46,0.085) 1px, transparent 1px)',
          backgroundSize: '57px 57px',
        }}
      />
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background:
            'radial-gradient(circle at 22% 72%, rgba(255,255,255,0.34), transparent 28%), radial-gradient(circle at 72% 28%, rgba(255,255,255,0.28), transparent 34%)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: 81,
          top: 63,
          color: 'rgba(45,42,36,0.42)',
          fontSize: 27,
          fontWeight: 800,
        }}
      >
        数字生命 King
      </div>
    </AbsoluteFill>
  );
};
