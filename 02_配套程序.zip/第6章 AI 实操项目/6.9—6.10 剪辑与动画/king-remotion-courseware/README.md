# King Remotion Courseware Skill

这是一个用于生成「数字生命 King」风格 Remotion 课程动画的 Codex Skill。

它内置了一个可复制的 Remotion 模板，重点解决：

- 左下角真人出镜安全区
- 底部字幕安全区
- 纸张网格背景
- 商用安全中文字体优先级
- 参考样本风格的清晰标题阴影
- 基于口播节奏的动效设计
- 可在 Remotion Studio 里调整的 `defaultProps`

## 创建新项目

```powershell
python "$HOME\.codex\skills\king-remotion-courseware\scripts\create_courseware_project.py" ".\my-new-remotion-course"
```

## 验证新项目

```powershell
cd ".\my-new-remotion-course"
npm install
npx tsc --noEmit
npm run scene1
```

## Skill 调用

在 Codex 里可以这样说：

```text
Use $king-remotion-courseware to create a Remotion courseware animation from this script and audio.
```
