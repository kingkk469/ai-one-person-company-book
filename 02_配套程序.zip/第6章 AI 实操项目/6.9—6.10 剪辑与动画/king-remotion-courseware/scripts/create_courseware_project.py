#!/usr/bin/env python
from __future__ import annotations

import argparse
import shutil
from pathlib import Path


def copy_template(destination: Path, overwrite: bool) -> None:
    skill_dir = Path(__file__).resolve().parents[1]
    template = skill_dir / "assets" / "remotion-courseware-template"

    if not template.exists():
        raise SystemExit(f"Template not found: {template}")

    if destination.exists():
        if not overwrite:
            raise SystemExit(f"Destination already exists: {destination}. Use --overwrite to replace it.")
        shutil.rmtree(destination)

    ignore = shutil.ignore_patterns("node_modules", "out", ".git", "*.log")
    shutil.copytree(template, destination, ignore=ignore)


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a King-style Remotion courseware project.")
    parser.add_argument("destination", help="Destination folder for the new Remotion project")
    parser.add_argument("--overwrite", action="store_true", help="Replace the destination folder if it exists")
    args = parser.parse_args()

    destination = Path(args.destination).expanduser().resolve()
    copy_template(destination, args.overwrite)
    print(f"Created Remotion courseware project: {destination}")
    print("Next: npm install && npx tsc --noEmit && npm run render")


if __name__ == "__main__":
    main()
