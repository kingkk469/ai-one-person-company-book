# Style Guide

Use this reference when refining the visual design.

## Layout

- Composition: native 1920x1080.
- Facecam safe zone: lower-left area, approximately x 0-520 and y 630-1080.
- Subtitle safe zone: lower-center area, approximately y 900-1080.
- Main teaching zone: upper center and center-right.

## Typography

Prefer installed open-source/commercially safe CJK fonts:

- `Noto Sans SC`
- `Source Han Sans CN`
- fallback: `Microsoft YaHei UI`, `Microsoft YaHei`

Do not bundle unknown commercial fonts. If a new font is requested, verify its license first.

## Shadow

Reference-style shadow is not a heavy black outline.

Use:

- bright foreground fill
- very thin dark edge
- down-right hard shadow with low opacity

Avoid:

- blur filters on text
- thick black outlines
- large offset duplicated text that invades the foreground
- scaling large text on entrance

## Background

Use warm paper with low-contrast grid lines. The grid should support the courseware feeling but not compete with large text.
