#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess


def find_ffmpeg(explicit: str | None) -> str:
    found = explicit or os.environ.get("FFMPEG") or shutil.which("ffmpeg")
    if found:
        return found
    if os.name == "nt":
        candidate = Path.home() / "AppData/Local/ChatCut/ffmpeg-recovered/ffmpeg.exe"
        if candidate.exists():
            return str(candidate)
    return ""


def safe_output(path: Path) -> Path:
    if not path.exists():
        return path
    counter = 1
    while True:
        candidate = path.with_name(f"{path.stem} ({counter}){path.suffix}")
        if not candidate.exists():
            return candidate
        counter += 1


def main() -> None:
    parser = argparse.ArgumentParser(description="按本地 EDL 渲染口播 MP4。")
    parser.add_argument("--edl", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--ffmpeg")
    parser.add_argument("--crf", type=int, default=18)
    parser.add_argument("--preset", default="medium")
    args = parser.parse_args()

    edl_path = Path(args.edl).expanduser().resolve()
    edl = json.loads(edl_path.read_text(encoding="utf-8"))
    source = Path(edl["source"]).expanduser().resolve()
    segments = edl.get("segments", [])
    fps = float(edl.get("fps", 30))
    if not source.is_file():
        raise SystemExit(f"源文件不存在：{source}")
    if not segments:
        raise SystemExit("EDL 没有 segments。")
    for index, segment in enumerate(segments):
        start, end = float(segment["start"]), float(segment["end"])
        if start < 0 or end <= start:
            raise SystemExit(f"无效区间 {index}: {start}-{end}")

    ffmpeg = find_ffmpeg(args.ffmpeg)
    if not ffmpeg:
        raise SystemExit("找不到 ffmpeg，请通过 --ffmpeg 指定路径。")
    output = safe_output(Path(args.output).expanduser().resolve())
    output.parent.mkdir(parents=True, exist_ok=True)

    filters, concat_inputs = [], []
    for index, segment in enumerate(segments):
        start = float(segment["start"])
        end = float(segment["end"])
        filters.append(f"[0:v]trim=start={start:.6f}:end={end:.6f},setpts=PTS-STARTPTS,fps={fps:g}[v{index}]")
        filters.append(f"[0:a]atrim=start={start:.6f}:end={end:.6f},asetpts=PTS-STARTPTS[a{index}]")
        concat_inputs.append(f"[v{index}][a{index}]")
    filters.append("".join(concat_inputs) + f"concat=n={len(segments)}:v=1:a=1[vout][aout]")
    command = [
        ffmpeg, "-hide_banner", "-loglevel", "warning", "-i", str(source),
        "-filter_complex", ";".join(filters), "-map", "[vout]", "-map", "[aout]",
        "-c:v", "libx264", "-preset", args.preset, "-crf", str(args.crf), "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-n", str(output),
    ]
    subprocess.run(command, check=True)
    print(str(output))


if __name__ == "__main__":
    main()
