param(
    [string]$Destination = (Join-Path $HOME ".codex\skills"),
    [switch]$Force
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$skillNames = @(
    "local-talking-head-editor",
    "king-audio-timed-remotion",
    "king-remotion-courseware",
    "jianying-editor"
)

New-Item -ItemType Directory -Path $Destination -Force | Out-Null

$results = foreach ($name in $skillNames) {
    $source = Join-Path $packageRoot $name
    $target = Join-Path $Destination $name

    if (-not (Test-Path -LiteralPath (Join-Path $source "SKILL.md"))) {
        throw "Course package is incomplete: $source\SKILL.md"
    }

    if ((Test-Path -LiteralPath $target) -and -not $Force) {
        [pscustomobject]@{ Skill = $name; Result = "exists; skipped"; Path = $target }
        continue
    }

    New-Item -ItemType Directory -Path $target -Force | Out-Null
    Copy-Item -Path (Join-Path $source "*") -Destination $target -Recurse -Force
    [pscustomobject]@{ Skill = $name; Result = "installed"; Path = $target }
}

$results | Format-Table -AutoSize
Write-Host "`nInstallation complete. Restart Codex, then verify the four skills."
