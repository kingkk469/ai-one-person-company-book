# 上游与授权

- 上游项目：<https://github.com/luoluoluo22/jianying-editor-skill>
- 课程打包版本：`1.5.0`
- 许可证：MIT，见同目录 `LICENSE`

课程仓库保留了生成剪映草稿所需的 Skill、规则、脚本、数据文件和依赖说明，去掉了 Git 历史、捐赠图片和大体积演示媒体。需要完整示例或上游更新时，请访问原项目。

