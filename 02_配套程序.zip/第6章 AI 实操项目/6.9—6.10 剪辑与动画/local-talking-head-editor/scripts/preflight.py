#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess


def find_tool(name: str, explicit: str | None = None) -> str:
    if explicit:
        return explicit
    env = os.environ.get(name.upper())
    if env:
        return env
    found = shutil.which(name)
    if found:
        return found
    if os.name == "nt" and name == "ffprobe":
        candidate = Path.home() / "AppData/Local/ChatCut/ffmpeg-recovered/ffprobe.exe"
        if candidate.exists():
            return str(candidate)
    raise SystemExit(f"找不到 {name}，请通过 --{name} 指定路径。")


def main() -> None:
    parser = argparse.ArgumentParser(description="检查本地口播源媒体。")
    parser.add_argument("video")
    parser.add_argument("--ffprobe")
    args = parser.parse_args()
    source = Path(args.video).expanduser().resolve()
    if not source.is_file():
        raise SystemExit(f"源文件不存在：{source}")
    ffprobe = find_tool("ffprobe", args.ffprobe)
    command = [
        ffprobe, "-v", "error", "-show_entries",
        "format=duration,size:stream=index,codec_type,codec_name,width,height,r_frame_rate,sample_rate,channels,start_time",
        "-of", "json", str(source),
    ]
    result = subprocess.run(command, check=True, capture_output=True, text=True, encoding="utf-8")
    data = json.loads(result.stdout)
    data["source"] = str(source)
    print(json.dumps(data, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

