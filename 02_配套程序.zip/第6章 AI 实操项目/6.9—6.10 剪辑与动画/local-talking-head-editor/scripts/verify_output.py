#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess


def find_ffprobe(explicit: str | None) -> str:
    if explicit:
        return explicit
    found = os.environ.get("FFPROBE") or shutil.which("ffprobe")
    if found:
        return found
    candidate = Path.home() / "AppData/Local/ChatCut/ffmpeg-recovered/ffprobe.exe"
    return str(candidate) if candidate.exists() else ""


def main() -> None:
    parser = argparse.ArgumentParser(description="验证本地口播成片。")
    parser.add_argument("--video", required=True)
    parser.add_argument("--edl", required=True)
    parser.add_argument("--ffprobe")
    args = parser.parse_args()
    video = Path(args.video).expanduser().resolve()
    edl = json.loads(Path(args.edl).expanduser().resolve().read_text(encoding="utf-8"))
    ffprobe = find_ffprobe(args.ffprobe)
    if not video.is_file() or not ffprobe:
        raise SystemExit("视频或 ffprobe 不可用。")
    command = [ffprobe, "-v", "error", "-show_entries", "format=duration,size:stream=codec_type,codec_name,width,height,r_frame_rate,sample_rate,channels", "-of", "json", str(video)]
    result = subprocess.run(command, check=True, capture_output=True, text=True, encoding="utf-8")
    media = json.loads(result.stdout)
    actual = float(media["format"]["duration"])
    expected = sum(float(s["end"]) - float(s["start"]) for s in edl["segments"])
    fps = float(edl.get("fps", 30))
    tolerance = max(0.05, 1.5 / fps)
    streams = media.get("streams", [])
    has_video = any(s.get("codec_type") == "video" for s in streams)
    has_audio = any(s.get("codec_type") == "audio" for s in streams)
    report = {
        "video": str(video),
        "expected_duration": round(expected, 3),
        "actual_duration": round(actual, 3),
        "duration_delta": round(actual - expected, 3),
        "has_video": has_video,
        "has_audio": has_audio,
        "streams": streams,
        "passed": abs(actual - expected) <= tolerance and has_video and has_audio,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not report["passed"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()

