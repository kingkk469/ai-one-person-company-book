#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def srt_time(seconds: float) -> str:
    millis = round(seconds * 1000)
    hours, millis = divmod(millis, 3_600_000)
    minutes, millis = divmod(millis, 60_000)
    secs, millis = divmod(millis, 1000)
    return f"{hours:02}:{minutes:02}:{secs:02},{millis:03}"


def main() -> None:
    parser = argparse.ArgumentParser(description="用 Faster Whisper 本地转写并生成 JSON/TXT/SRT。")
    parser.add_argument("video")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--model", default="small")
    parser.add_argument("--language", default="zh")
    args = parser.parse_args()

    from faster_whisper import WhisperModel

    source = Path(args.video).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    if not source.is_file():
        raise SystemExit(f"源文件不存在：{source}")

    try:
        import torch
        use_cuda = bool(torch.cuda.is_available())
    except Exception:
        use_cuda = False
    model = WhisperModel(args.model, device="cuda" if use_cuda else "cpu", compute_type="float16" if use_cuda else "int8")
    segments_iter, info = model.transcribe(str(source), language=args.language, vad_filter=True, word_timestamps=True)
    segments = []
    for segment in segments_iter:
        segments.append({
            "start": segment.start,
            "end": segment.end,
            "text": segment.text.strip(),
            "words": [
                {"start": word.start, "end": word.end, "text": word.word}
                for word in (segment.words or [])
            ],
        })
    payload = {
        "version": 1,
        "source": str(source),
        "language": info.language,
        "language_probability": info.language_probability,
        "segments": segments,
    }
    stem = source.stem
    (output_dir / f"{stem}.transcript.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / f"{stem}.txt").write_text("\n".join(s["text"] for s in segments) + "\n", encoding="utf-8")
    srt = []
    for index, segment in enumerate(segments, 1):
        srt.extend([str(index), f"{srt_time(segment['start'])} --> {srt_time(segment['end'])}", segment["text"], ""])
    (output_dir / f"{stem}.srt").write_text("\n".join(srt), encoding="utf-8")
    print(json.dumps({"segments": len(segments), "output_dir": str(output_dir)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

