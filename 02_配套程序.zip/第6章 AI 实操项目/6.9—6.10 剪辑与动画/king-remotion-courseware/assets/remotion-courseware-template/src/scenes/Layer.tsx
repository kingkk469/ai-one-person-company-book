import React from 'react';
import {interpolate, spring, useVideoConfig} from 'remotion';
import {ElementProps} from '../sceneProps';

const DESIGN_SCALE = 1.5;
const s = (value: number) => value * DESIGN_SCALE;

export const usePop = (frame: number, startFrame: number) => {
  const {fps} = useVideoConfig();
  return spring({
    frame: frame - startFrame,
    fps,
    config: {
      damping: 13,
      mass: 0.7,
      stiffness: 150,
    },
  });
};

export const ControlledLayer: React.FC<{
  frame: number;
  props: ElementProps;
  left: number;
  top: number;
  width?: number;
  height?: number;
  origin?: string;
  children: React.ReactNode;
}> = ({frame, props, left, top, width, height, origin = 'center center', children}) => {
  const progress = usePop(frame, props.startFrame);

  return (
    <div
      style={{
        position: 'absolute',
        left: s(left),
        top: s(top),
        width: width === undefined ? undefined : s(width),
        height: height === undefined ? undefined : s(height),
        transform: `translate(${Math.round(s(props.x))}px, ${Math.round(s(props.y + interpolate(progress, [0, 1], [28, 0])))}px) scale(${props.scale})`,
        transformOrigin: origin,
        opacity: interpolate(progress, [0, 0.25, 1], [0, 1, 1]),
      }}
    >
      {children}
    </div>
  );
};

export const StaticControlledLayer: React.FC<{
  props: ElementProps;
  left: number;
  top: number;
  width?: number;
  height?: number;
  origin?: string;
  children: React.ReactNode;
}> = ({props, left, top, width, height, origin = 'center center', children}) => {
  return (
    <div
      style={{
        position: 'absolute',
        left: s(left),
        top: s(top),
        width: width === undefined ? undefined : s(width),
        height: height === undefined ? undefined : s(height),
        transform: `translate(${Math.round(s(props.x))}px, ${Math.round(s(props.y))}px) scale(${props.scale})`,
        transformOrigin: origin,
      }}
    >
      {children}
    </div>
  );
};
