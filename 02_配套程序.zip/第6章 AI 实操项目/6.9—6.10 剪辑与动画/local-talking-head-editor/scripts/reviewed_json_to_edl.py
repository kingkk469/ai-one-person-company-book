#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def srt_time(seconds: float) -> str:
    millis = round(seconds * 1000)
    hours, millis = divmod(millis, 3_600_000)
    minutes, millis = divmod(millis, 60_000)
    secs, millis = divmod(millis, 1000)
    return f"{hours:02}:{minutes:02}:{secs:02},{millis:03}"


def main() -> None:
    parser = argparse.ArgumentParser(description="把人工审校字幕 JSON 转为本地剪辑 EDL 和剪后 SRT。")
    parser.add_argument("--review", required=True)
    parser.add_argument("--source", required=True)
    parser.add_argument("--output-edl", required=True)
    parser.add_argument("--output-srt", required=True)
    parser.add_argument("--fps", type=float, required=True)
    parser.add_argument("--width", type=int, required=True)
    parser.add_argument("--height", type=int, required=True)
    parser.add_argument("--merge-gap", type=float, default=0.8)
    parser.add_argument("--handle", type=float, default=0.2)
    parser.add_argument("--source-duration", type=float)
    args = parser.parse_args()

    payload = json.loads(Path(args.review).read_text(encoding="utf-8"))
    subs = payload.get("segments", [])
    if not subs:
        raise SystemExit("人工审校 JSON 没有可用 segments")
    previous_end = -1.0
    for sub in subs:
        if not isinstance(sub.get("text"), str) or sub["end"] <= sub["start"] or sub["start"] < previous_end:
            raise SystemExit("字幕存在空文本、倒置、重叠或乱序时间码")
        previous_end = sub["end"]

    groups = []
    for sub in subs:
        if not groups or sub["start"] - groups[-1]["raw_end"] > args.merge_gap:
            groups.append({"raw_start": sub["start"], "raw_end": sub["end"], "subs": [sub]})
        else:
            groups[-1]["raw_end"] = sub["end"]
            groups[-1]["subs"].append(sub)

    source_end = args.source_duration if args.source_duration is not None else groups[-1]["raw_end"] + args.handle
    clips = []
    for index, group in enumerate(groups):
        prior = groups[index - 1]["raw_end"] if index else 0.0
        following = groups[index + 1]["raw_start"] if index + 1 < len(groups) else source_end
        start = max(prior, group["raw_start"] - args.handle)
        end = min(following, group["raw_end"] + args.handle)
        clips.append({"start": round(start, 3), "end": round(end, 3), "label": f"speech-{index + 1:02d}"})

    edl = {"version": 1, "source": str(Path(args.source).resolve()), "fps": args.fps,
           "width": args.width, "height": args.height, "segments": clips}
    Path(args.output_edl).write_text(json.dumps(edl, ensure_ascii=False, indent=2), encoding="utf-8")

    srt = []
    cursor = 0.0
    number = 1
    for group, clip in zip(groups, clips):
        for sub in group["subs"]:
            start = cursor + sub["start"] - clip["start"]
            end = cursor + sub["end"] - clip["start"]
            srt.extend([str(number), f"{srt_time(start)} --> {srt_time(end)}", sub["text"], ""])
            number += 1
        cursor += clip["end"] - clip["start"]
    Path(args.output_srt).write_text("\n".join(srt), encoding="utf-8")
    print(json.dumps({"clips": len(clips), "subtitles": len(subs), "duration": round(cursor, 3)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
