#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description="生成本地逐句字幕审校页面。")
    parser.add_argument("--transcript", required=True)
    parser.add_argument("--video", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    transcript = Path(args.transcript).resolve()
    video = Path(args.video).resolve()
    if not transcript.is_file() or not video.is_file():
        raise SystemExit("转写 JSON 或原视频不存在")
    payload = json.loads(transcript.read_text(encoding="utf-8"))
    segments = payload.get("segments", [])
    if not segments:
        raise SystemExit("转写 JSON 没有 segments")
    data = json.dumps(segments, ensure_ascii=False).replace("</", "<\\/")
    key = "subtitle-review-" + hashlib.sha256(str(transcript).encode()).hexdigest()[:12]
    video_uri = video.as_uri().replace("'", "%27")

    template = r'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>逐句字幕审校台</title><style>
:root{--ink:#191713;--paper:#f1eadb;--red:#c83e2b;--green:#24745a;--line:#b9ae98}*{box-sizing:border-box}body{margin:0;background:var(--ink);font-family:"Noto Serif SC","Songti SC",serif}.shell{min-height:100vh;display:grid;grid-template-columns:minmax(360px,42vw) 1fr}.stage{position:sticky;top:0;height:100vh;padding:28px;background:#11100e;color:var(--paper);display:flex;flex-direction:column;gap:16px}.stage h1{margin:0;font-size:27px;letter-spacing:.08em}video{width:100%;max-height:56vh;background:#000;border:1px solid #4a463d}.pick{border:1px dashed #807663;padding:12px;text-align:center;color:#c8beaa;cursor:pointer}.pick input{display:none}.now{padding:14px 0;border-block:1px solid #49443a}.now span{color:#dbad66;font-family:Consolas,monospace}.now p{font-size:21px;line-height:1.5}.desk{background:var(--paper);min-height:100vh;padding:28px 32px 90px}.tools{position:sticky;top:0;z-index:3;background:linear-gradient(var(--paper) 80%,transparent);padding-bottom:24px;display:grid;grid-template-columns:1fr auto;gap:12px}.actions{display:flex;gap:7px;flex-wrap:wrap;justify-content:end}input[type=search]{width:100%;border:0;border-bottom:2px solid var(--ink);background:transparent;padding:9px 0;font:17px inherit;outline:none}button{border:1px solid var(--ink);background:transparent;padding:8px 11px;font:14px inherit;cursor:pointer}.primary{background:var(--ink);color:var(--paper)}.stats{font-size:13px;color:#746c5f;margin-top:7px}.list{display:flex;flex-direction:column}.row{display:grid;grid-template-columns:78px 1fr 40px;gap:12px;padding:13px 10px;border-top:1px solid var(--line)}.row:hover,.row.active{background:#fff8e9}.row.deleted{opacity:.42}.row.deleted textarea{text-decoration:line-through}.time{font:12px/1.5 Consolas,monospace;color:var(--red);cursor:pointer}textarea{width:100%;resize:none;overflow:hidden;border:0;background:transparent;font:18px/1.55 inherit;outline:none}.toggle{width:35px;height:35px;border-radius:50%;padding:0}.deleted .toggle{background:var(--green);color:#fff}.toast{position:fixed;right:20px;bottom:20px;background:var(--ink);color:var(--paper);padding:11px 14px;opacity:0;transition:.2s}.toast.show{opacity:1}@media(max-width:900px){.shell{display:block}.stage{position:relative;height:auto}.desk{padding:20px 14px 80px}.tools{position:relative}.row{grid-template-columns:70px 1fr 38px}}
</style></head><body><main class="shell"><section class="stage"><h1>逐句字幕审校台</h1><video id="video" controls preload="metadata" src="__VIDEO__"></video><label class="pick">原视频已自动加载 · 路径变化时点此重选<input id="file" type="file" accept="video/*"></label><div class="now"><span id="tc">00:00.00</span><p id="now">点击右侧时间码开始核听</p></div><small>修改自动保存在当前浏览器；导出不会覆盖上一版。</small></section><section class="desk"><div class="tools"><div><input id="search" type="search" placeholder="搜索字幕…"><div id="stats" class="stats"></div></div><div class="actions"><button id="restore">恢复上一版</button><button id="txt">导出 TXT</button><button id="srt">导出 SRT</button><button id="json" class="primary">导出审校 JSON</button></div></div><div id="list" class="list"></div></section></main><div id="toast" class="toast"></div><script>
const BASE=__DATA__,KEY='__KEY__';let rows=JSON.parse(localStorage.getItem(KEY)||'null')||BASE.map((s,i)=>({...s,_id:i+1,deleted:false,baseText:s.text}));const $=s=>document.querySelector(s),video=$('#video'),list=$('#list');function time(s,srt=false){let x=Math.round(s*1000),h=Math.floor(x/3600000);x%=3600000;let m=Math.floor(x/60000);x%=60000;let q=Math.floor(x/1000),z=x%1000;return srt?`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(q).padStart(2,'0')},${String(z).padStart(3,'0')}`:`${String(m+h*60).padStart(2,'0')}:${String(q).padStart(2,'0')}.${String(Math.floor(z/10)).padStart(2,'0')}`}function save(){localStorage.setItem(KEY,JSON.stringify(rows));stats()}function fit(t){t.style.height='auto';t.style.height=t.scrollHeight+'px'}function render(){let q=$('#search').value.trim().toLowerCase();list.innerHTML='';rows.forEach(r=>{if(q&&!r.text.toLowerCase().includes(q))return;let e=document.createElement('div');e.className='row'+(r.deleted?' deleted':'');e.innerHTML=`<div class="time">${time(r.start)}<br>#${r._id}</div><textarea></textarea><button class="toggle">${r.deleted?'↩':'×'}</button>`;let t=e.querySelector('textarea');t.value=r.text;fit(t);t.oninput=()=>{r.text=t.value;fit(t);save()};e.querySelector('.time').onclick=()=>{video.currentTime=Math.max(0,r.start-.2);video.play();$('.row.active')?.classList.remove('active');e.classList.add('active');$('#now').textContent=r.text};e.querySelector('.toggle').onclick=()=>{r.deleted=!r.deleted;save();render()};list.appendChild(e)});stats()}function stats(){let c=rows.filter(r=>r.text!==r.baseText).length,d=rows.filter(r=>r.deleted).length;$('#stats').textContent=`${rows.length} 句 · 修改 ${c} 句 · 删除 ${d} 句`}function kept(){return rows.filter(r=>!r.deleted)}function dl(name,text,type='text/plain'){let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}function srt(){return kept().map((r,i)=>`${i+1}\n${time(r.start,true)} --> ${time(r.end,true)}\n${r.text}\n`).join('\n')}$('#file').onchange=e=>{let f=e.target.files[0];if(f)video.src=URL.createObjectURL(f)};$('#search').oninput=render;$('#txt').onclick=()=>dl('人工审校版.txt',kept().map(r=>r.text).join('\n'));$('#srt').onclick=()=>dl('人工审校版.srt',srt());$('#json').onclick=()=>dl('人工审校版.json',JSON.stringify({version:1,segments:kept().map(({baseText,deleted,_id,...r})=>r)},null,2),'application/json');$('#restore').onclick=()=>{if(confirm('恢复上一版并清除当前修改？')){localStorage.removeItem(KEY);location.reload()}};video.ontimeupdate=()=>$('#tc').textContent=time(video.currentTime);render();
</script></body></html>'''
    html = template.replace("__DATA__", data).replace("__VIDEO__", video_uri).replace("__KEY__", key)
    Path(args.output).write_text(html, encoding="utf-8")
    print(Path(args.output).resolve())


if __name__ == "__main__":
    main()
