﻿import React from 'react';
import {interpolate} from 'remotion';
import {SceneProps} from '../sceneProps';
import {ControlledLayer, StaticControlledLayer} from './Layer';

const palette = {
  ink: '#28241f',
  yellow: '#f0c23a',
  blue: '#78a9d8',
  purple: '#d4b7d3',
  olive: '#c8ca73',
  red: '#d84d55',
  paper: '#f7f2e8',
};

const S = 1.5;
const s = (value: number) => value * S;

const popStyle = (frame: number, startFrame: number) => {
  const progress = interpolate(frame - startFrame, [0, 14], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return {
    opacity: interpolate(progress, [0, 0.2, 1], [0, 1, 1]),
    transform: `translateY(${Math.round(s(interpolate(progress, [0, 1], [22, 0])))}px)`,
  };
};

const RightStage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div style={{position: 'absolute', left: s(220), top: s(70), width: s(980), height: s(560)}}>{children}</div>
);

const FaceSafeArea: React.FC = () => (
  <div
    style={{
      position: 'absolute',
      left: s(88),
      top: s(418),
      width: s(300),
      height: s(250),
      borderRadius: 999,
      pointerEvents: 'none',
    }}
  />
);

const BigText: React.FC<{children: React.ReactNode; color?: string; size?: number; lineHeight?: number}> = ({
  children,
  color = palette.yellow,
  size = 82,
  lineHeight = 1.08,
}) => (
  <div
    style={{
      position: 'relative',
      color,
      fontSize: s(size),
      lineHeight,
      fontWeight: 900,
      fontFamily: 'Noto Sans SC, Source Han Sans CN, Microsoft YaHei UI, Microsoft YaHei, Arial, sans-serif',
      letterSpacing: 0,
      WebkitTextStroke: `${s(size >= 58 ? 0.55 : 0.35)}px rgba(70,52,20,0.62)`,
      WebkitFontSmoothing: 'antialiased',
      textRendering: 'geometricPrecision',
    }}
  >
    {children}
  </div>
);

const Pill: React.FC<{children: React.ReactNode; color: string}> = ({children, color}) => (
  <div
    style={{
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: s(54),
      padding: `0 ${s(28)}px`,
      borderRadius: s(4),
      background: color,
      color: palette.ink,
      fontSize: s(30),
      fontWeight: 900,
      boxShadow: `${s(3)}px ${s(4)}px 0 rgba(0,0,0,0.22)`,
    }}
  >
    {children}
  </div>
);

const ChatBubble: React.FC = () => (
  <div
    style={{
      width: s(258),
      height: s(112),
      background: '#ffffff',
      border: `${s(5)}px solid ${palette.ink}`,
      borderRadius: s(18),
      boxShadow: `${s(3)}px ${s(4)}px 0 rgba(0,0,0,0.22)`,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: s(48),
      fontWeight: 950,
      color: palette.ink,
      position: 'relative',
    }}
  >
    你好
    <div
      style={{
        position: 'absolute',
        right: s(32),
        bottom: s(-23),
        width: s(38),
        height: s(38),
        background: '#ffffff',
        borderRight: `${s(5)}px solid ${palette.ink}`,
        borderBottom: `${s(5)}px solid ${palette.ink}`,
        transform: 'rotate(45deg)',
      }}
    />
  </div>
);

const TokenMeter: React.FC<{frame: number; startFrame: number}> = ({frame, startFrame}) => {
  const fill = interpolate(frame - startFrame, [0, 20, 34, 46], [0, 0.42, 0.98, 0.92], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const shine = interpolate(frame - startFrame, [14, 42], [-120, 385], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const counter = Math.round(
    interpolate(frame - startFrame, [0, 40], [0, 14], {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
    }),
  );
  const warningOpacity = interpolate(frame - startFrame, [30, 42], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const pulse = interpolate(frame - startFrame, [38, 43, 50], [1, 1.08, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <div style={{width: s(450)}}>
      <div style={{display: 'flex', alignItems: 'baseline', gap: s(18), marginBottom: s(12)}}>
        <div style={{fontSize: s(28), fontWeight: 900, color: palette.ink}}>Token 消耗条</div>
        <div
          style={{
            opacity: warningOpacity,
            transform: `scale(${pulse})`,
            transformOrigin: 'right center',
            fontSize: s(28),
            color: palette.red,
            fontWeight: 950,
          }}
        >
          {counter}万+
        </div>
      </div>
      <div
        style={{
          height: s(46),
          border: `${s(4)}px solid ${palette.ink}`,
          background: '#fff7d6',
          boxShadow: `${s(3)}px ${s(4)}px 0 rgba(0,0,0,0.18)`,
          overflow: 'hidden',
          position: 'relative',
        }}
      >
        <div
          style={{
            width: '100%',
            height: '100%',
            transform: `scaleX(${fill})`,
            transformOrigin: 'left center',
            background: `repeating-linear-gradient(90deg, ${palette.red} 0 22px, #f49aa0 22px 30px)`,
          }}
        />
        <div
          style={{
            position: 'absolute',
            left: s(shine),
            top: s(-8),
            width: s(42),
            height: s(62),
            background: 'rgba(255,255,255,0.72)',
            transform: 'skewX(-18deg)',
          }}
        />
        {[0.25, 0.5, 0.75].map((left) => (
          <div
            key={left}
            style={{
              position: 'absolute',
              left: `${left * 100}%`,
              top: 0,
              width: s(4),
              height: '100%',
              background: 'rgba(40,36,31,0.32)',
            }}
          />
        ))}
      </div>
      <div
        style={{
          marginTop: s(14),
          fontSize: s(24),
          color: palette.red,
          fontWeight: 900,
          opacity: interpolate(frame - startFrame, [42, 54], [0, 1], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
          }),
        }}
      >
        看着便宜，用起来飞快
      </div>
    </div>
  );
};

const FormulaBox: React.FC = () => (
  <div style={{display: 'flex', gap: s(18), alignItems: 'center'}}>
    <Pill color={palette.blue}>输入</Pill>
    <BigText color={palette.ink} size={46}>+</BigText>
    <Pill color={palette.purple}>输出</Pill>
    <BigText color={palette.ink} size={46}>+</BigText>
    <Pill color={palette.olive}>上下文</Pill>
  </div>
);

const PriceTable: React.FC<{frame: number; startFrame: number}> = ({frame, startFrame}) => {
  const rows = [
    ['模型 A', '便宜', '适合批量跑'],
    ['模型 B', '中等', '适合日常写作'],
    ['模型 C', '更贵', '适合复杂推理'],
  ];

  return (
    <div style={{width: s(700), border: `${s(5)}px solid ${palette.ink}`, background: '#fffdf6', boxShadow: `${s(4)}px ${s(5)}px 0 rgba(0,0,0,0.2)`}}>
      <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr 1.45fr', background: palette.ink, color: '#fff', fontSize: s(27), fontWeight: 950}}>
        <div style={{padding: `${s(15)}px ${s(18)}px`}}>主流模型</div>
        <div style={{padding: `${s(15)}px ${s(18)}px`}}>价格感</div>
        <div style={{padding: `${s(15)}px ${s(18)}px`}}>该怎么用</div>
      </div>
      {rows.map((row, index) => {
        const reveal = interpolate(frame - startFrame, [index * 13 + 8, index * 13 + 20], [0, 1], {
          extrapolateLeft: 'clamp',
          extrapolateRight: 'clamp',
        });
        const active = interpolate(frame - startFrame, [index * 18 + 44, index * 18 + 52, index * 18 + 66], [0, 1, 0], {
          extrapolateLeft: 'clamp',
          extrapolateRight: 'clamp',
        });

        return (
          <div
            key={row[0]}
            style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr 1.45fr',
              minHeight: s(64),
              borderTop: `${s(4)}px solid ${palette.ink}`,
              color: palette.ink,
              fontSize: s(25),
              fontWeight: 900,
              background: active > 0 ? '#fff3bb' : index === 1 ? '#f8f0fb' : '#fffdf6',
              opacity: reveal,
              transform: `translateX(${Math.round(s((1 - reveal) * 22))}px)`,
            }}
          >
            <div style={{padding: `${s(16)}px ${s(18)}px`}}>{row[0]}</div>
            <div style={{padding: `${s(16)}px ${s(18)}px`, color: index === 2 ? palette.red : palette.blue}}>{row[1]}</div>
            <div style={{padding: `${s(16)}px ${s(18)}px`}}>{row[2]}</div>
          </div>
        );
      })}
    </div>
  );
};

const Checklist: React.FC<{frame: number; startFrame: number}> = ({frame, startFrame}) => {
  const items = [
    ['短上下文', '别把整本资料都塞进去'],
    ['分模型', '简单任务用便宜模型'],
    ['分步骤', '先问清楚，再让它生成'],
    ['可复用', '固定提示词和资料包'],
  ];

  return (
    <div style={{display: 'grid', gap: s(14), width: s(680)}}>
      {items.map((item, index) => {
        const reveal = interpolate(frame - startFrame, [index * 12, index * 12 + 10], [0, 1], {
          extrapolateLeft: 'clamp',
          extrapolateRight: 'clamp',
        });

        return (
          <div
            key={item[0]}
            style={{
              display: 'grid',
              gridTemplateColumns: `${s(190)}px 1fr`,
              alignItems: 'center',
              columnGap: s(18),
              opacity: reveal,
              transform: `translateY(${Math.round(s((1 - reveal) * 18))}px)`,
            }}
          >
            <Pill color={[palette.yellow, palette.blue, palette.purple, palette.olive][index]}>{item[0]}</Pill>
            <div style={{position: 'relative', fontSize: s(30), fontWeight: 850, color: palette.ink}}>
              {item[1]}
              <div
                style={{
                  position: 'absolute',
                  left: 0,
                  bottom: s(-4),
                  height: s(6),
                  width: `${reveal * 92}%`,
                  background: 'rgba(240,200,76,0.48)',
                  zIndex: -1,
                }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};

export const Scene01: React.FC<{frame: number; props: SceneProps['scene01']}> = ({frame, props}) => {
  return (
    <>
      <FaceSafeArea />
      <RightStage>
        <ControlledLayer frame={frame} props={props.eyebrow} left={300} top={10} width={430}>
          <Pill color={palette.olive}>今天讲 Token 计费</Pill>
        </ControlledLayer>
        <StaticControlledLayer props={props.headline} left={55} top={95} width={780}>
          <div style={popStyle(frame, props.headline.startFrame)}>
            <BigText>AI 的钱，<br />到底花在哪？</BigText>
          </div>
        </StaticControlledLayer>
        <ControlledLayer frame={frame} props={props.bubble} left={700} top={285} width={258} height={112}>
          <ChatBubble />
        </ControlledLayer>
        <ControlledLayer frame={frame} props={props.meter} left={300} top={370} width={450}>
          <TokenMeter frame={frame} startFrame={props.meter.startFrame} />
        </ControlledLayer>
      </RightStage>
    </>
  );
};

export const Scene02: React.FC<{frame: number; props: SceneProps['scene02']}> = ({frame, props}) => {
  return (
    <>
      <FaceSafeArea />
      <RightStage>
        <StaticControlledLayer props={props.headline} left={190} top={12} width={760}>
          <div style={popStyle(frame, props.headline.startFrame)}>
            <BigText color={palette.blue} size={62}>发个“你好”</BigText>
          </div>
        </StaticControlledLayer>
        <StaticControlledLayer props={props.tokenNumber} left={80} top={122} width={820}>
          <div style={popStyle(frame, props.tokenNumber.startFrame)}>
            <BigText color={palette.yellow} size={118}>14 万 Token</BigText>
          </div>
        </StaticControlledLayer>
        <ControlledLayer frame={frame} props={props.formula} left={150} top={325} width={720}>
          <FormulaBox />
        </ControlledLayer>
        <ControlledLayer frame={frame} props={props.note} left={190} top={445} width={650}>
          <div style={{fontSize: s(34), lineHeight: 1.35, color: palette.ink, fontWeight: 900}}>
            不是一句话贵，<br />是它背后带着一大段上下文。
          </div>
        </ControlledLayer>
      </RightStage>
    </>
  );
};

export const Scene03: React.FC<{frame: number; props: SceneProps['scene03']}> = ({frame, props}) => {
  return (
    <>
      <FaceSafeArea />
      <RightStage>
        <StaticControlledLayer props={props.title} left={150} top={0} width={760}>
          <div style={popStyle(frame, props.title.startFrame)}>
            <BigText color={palette.purple} size={58}>用价格表，看懂选择</BigText>
          </div>
        </StaticControlledLayer>
        <ControlledLayer frame={frame} props={props.table} left={170} top={126} width={700}>
          <PriceTable frame={frame} startFrame={props.table.startFrame} />
        </ControlledLayer>
        <ControlledLayer frame={frame} props={props.callout} left={210} top={465} width={650}>
          <div style={{fontSize: s(30), lineHeight: 1.34, color: palette.ink, fontWeight: 900}}>
            同一件事，不同模型成本差很多。<br />关键是：<span style={{color: palette.red}}>让对的模型干对的活。</span>
          </div>
        </ControlledLayer>
      </RightStage>
    </>
  );
};

export const Scene04: React.FC<{frame: number; props: SceneProps['scene04']}> = ({frame, props}) => {
  return (
    <>
      <FaceSafeArea />
      <RightStage>
        <StaticControlledLayer props={props.conclusion} left={120} top={0} width={780}>
          <div style={popStyle(frame, props.conclusion.startFrame)}>
            <BigText color={palette.yellow} size={58}>省钱不是目的，<br />效率才是。</BigText>
          </div>
        </StaticControlledLayer>
        <ControlledLayer frame={frame} props={props.checklist} left={210} top={175} width={690}>
          <Checklist frame={frame} startFrame={props.checklist.startFrame} />
        </ControlledLayer>
        <ControlledLayer frame={frame} props={props.finalLine} left={200} top={470} width={660}>
          <div style={{fontSize: s(38), fontWeight: 950, color: palette.blue}}>
            合理省 Token，就是提高 AI 投产比。
          </div>
        </ControlledLayer>
      </RightStage>
    </>
  );
};
