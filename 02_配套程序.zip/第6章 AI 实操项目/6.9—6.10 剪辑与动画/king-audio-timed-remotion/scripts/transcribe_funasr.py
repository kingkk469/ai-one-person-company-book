import json
import os
import sys
from pathlib import Path

from funasr import AutoModel


MODEL_ROOT = Path(
    os.environ.get(
        "FUNASR_MODEL_ROOT",
        Path.home() / ".cache" / "modelscope" / "hub" / "models" / "iic",
    )
).expanduser()
ASR_MODEL = MODEL_ROOT / "speech_paraformer-large-vad-punc_asr_nat-zh-cn-16k-common-vocab8404-pytorch"
VAD_MODEL = MODEL_ROOT / "speech_fsmn_vad_zh-cn-16k-common-pytorch"
PUNC_MODEL = MODEL_ROOT / "punc_ct-transformer_cn-en-common-vocab471067-large"


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: transcribe_funasr.py INPUT_AUDIO OUTPUT_JSON")

    for model_path in (ASR_MODEL, VAD_MODEL, PUNC_MODEL):
        if not model_path.exists():
            raise SystemExit(f"Missing local FunASR model: {model_path}")

    model = AutoModel(
        model=str(ASR_MODEL),
        vad_model=str(VAD_MODEL),
        punc_model=str(PUNC_MODEL),
        device=os.environ.get("FUNASR_DEVICE", "cpu"),
        disable_update=True,
    )
    result = model.generate(
        input=sys.argv[1],
        batch_size_s=120,
        sentence_timestamp=True,
    )
    output_path = Path(sys.argv[2])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
