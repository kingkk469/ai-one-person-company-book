﻿import {z} from 'zod';

const propElementSchema = z.object({
  x: z.number().min(-500).max(500).step(1),
  y: z.number().min(-500).max(500).step(1),
  scale: z.number().min(0.2).max(3).step(0.01),
  startFrame: z.number().min(0).max(180).step(1),
});

export const scenePropsSchema = z.object({
  scene01: z.object({
    eyebrow: propElementSchema,
    headline: propElementSchema,
    bubble: propElementSchema,
    meter: propElementSchema,
  }),
  scene02: z.object({
    headline: propElementSchema,
    tokenNumber: propElementSchema,
    formula: propElementSchema,
    note: propElementSchema,
  }),
  scene03: z.object({
    title: propElementSchema,
    table: propElementSchema,
    callout: propElementSchema,
  }),
  scene04: z.object({
    conclusion: propElementSchema,
    checklist: propElementSchema,
    finalLine: propElementSchema,
  }),
});

export type ElementProps = z.infer<typeof propElementSchema>;
export type SceneProps = z.infer<typeof scenePropsSchema>;
